# Copyright © 2020, Oracle and/or its affiliates. All rights reserved.
# The Universal Permissive License (UPL), Version 1.0*/

#!/bin/sh

set -e
set -x

#### Install Ansible, oci-cli, oci-sdk, git, jq ########
#sudo yum install -y ansible git jq python-oci-cli python-oci-sdk
sudo yum install -y git jq
yum -y install oraclelinux-developer-release-el7 && sudo yum -y install oci-ansible-collection

# Clone and Install OCI ansible modules
git clone https://github.com/oracle-quickstart/oci-db-patching /home/opc/oci-db-patching
chown -R opc:opc /home/opc/oci-db-patching

exit 0
